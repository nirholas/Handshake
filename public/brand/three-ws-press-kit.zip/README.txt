three.ws press kit
==================

Everything here is current as of the build that produced this archive. The live
copy, with boilerplate and fast facts, is at https://three.ws/press

marks/
  three-ws-mark.png              The cube on its own. Transparent.
  three-ws-lockup-on-dark.png    Cube + wordmark, light type, for dark grounds.
  three-ws-lockup-on-light.png   Cube + wordmark, dark type, for light grounds.
  three-ws-stacked-on-dark.png   Stacked, light type, for square crops.
  three-ws-stacked-on-light.png  Stacked, dark type, for square crops.

openai/
  Announcement graphics for our OpenAI Select Partner status, plus OpenAI's
  badge as they supplied it. The badge is OpenAI's asset: reproduce it
  unaltered, and do not imply OpenAI endorses a three.ws product. three.ws is an
  independent member of the OpenAI Partner Network at the Select tier. OpenAI,
  ChatGPT, and the OpenAI Partner Network badge are trademarks of OpenAI.

Using the marks
  1. Use the files as they are. No recolouring, outlining, stretching,
     rotating, or rebuilding the cube from parts.
  2. Leave at least half the cube's height of clear space on every side.
  3. Write the name lowercase: three.ws.
  4. Do not lock our mark to another logo without asking.
  5. Editorial use is granted. Coverage, reviews, conference programmes, and
     partner materials need no permission. Using the mark as your own product
     mark, or in a way that implies we endorse a product, does.

Contact: partnerships@three.ws
